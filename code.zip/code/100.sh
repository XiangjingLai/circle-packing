#!/bin/sh
./IDTS 100 3 250 