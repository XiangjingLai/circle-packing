The format of solution file is as follows: 
The first line contains the number of unit circles (N) and the radius of container (R). 
As for the remaining parts, each line contains the X-coordinate and Y-coordinate of the center of one circle. 